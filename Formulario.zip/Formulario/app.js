var nameuser = 'ecueva07'
var passuser = 'Mane07'

function buscarusua() {
    var usuariotemp = document.getElementById("usuario")
    var passtemp = document.getElementById("contrasena")

    if (usuariotemp === "nameuser" && passtemp === "passuser") {
        console.log('Bienvenido')
    } else {
        console.log('Usuario o contraseña incorrecta')


    }
}